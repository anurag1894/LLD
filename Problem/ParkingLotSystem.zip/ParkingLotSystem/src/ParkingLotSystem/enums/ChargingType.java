package ParkingLotSystem.enums;

public enum ChargingType {
    HOURLY,
    FIXED
}
