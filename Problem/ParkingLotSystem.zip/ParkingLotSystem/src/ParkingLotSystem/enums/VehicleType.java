package ParkingLotSystem.enums;

public enum VehicleType {
    CAR,
    BUS
}
