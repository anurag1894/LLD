package ParkingLotSystem.enums;

public enum PaymentType {
    UPI,
    CARD,
    CASH
}
