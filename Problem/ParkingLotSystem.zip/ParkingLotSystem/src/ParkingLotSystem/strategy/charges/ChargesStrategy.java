package ParkingLotSystem.strategy.charges;

public interface ChargesStrategy {
    public int getCharges();
}
